
const images = document.querySelector('.images');
const zoom = document.querySelector('.pop-up');
const body = document.querySelector('body');
const imgDiv = zoom.children[0];
const show = imgDiv.children[0]

async function showImg() {
    try {
        let response = await fetch('https://jsonplaceholder.typicode.com/albums/1/photos');
        let file = await response.json();
        let img = file.forEach(el => {
        const image = document.createElement('img');
        image.classList.add('image')
        image.src = el.url; 
        images.appendChild(image);
    });
    } catch (error) {
        console.log(error);
    }
}

showImg();
images.addEventListener('click', (e)=>{
    let target = e.target;
    if(target.className === 'image'){
        zoom.style.display = 'block';
        const zurag = document.getElementById('zurag');
        show.src = target.src;
        show.style.position = 'absolute';
        show.style.left = '23%';
        show.style.top = '10%';
        zoom.appendChild(show)
        body.style.overflow = 'hidden';
    }
})

show.addEventListener('click', ()=>{
    zoom.style.display = 'none';
    body.style.overflow = 'auto';
})