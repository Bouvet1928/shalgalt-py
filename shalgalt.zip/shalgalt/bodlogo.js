

//1






// function isInArray(array, num) {
//     for (let i = 0; i < array.length; i++) {
//       if (array[i] === num) {
//         return "The number " + num + " is  array.";
//       }
//     }
//     return "The number " + num + " is not  array.";
//   }
  
//   let arr = [1, 2, 3, 4, 5];
//   let number = 2;
//   console.log(isInArray(arr, number));








//2





// function calculateFactorials(num) {
//     for (let i = 1; i <= num; i++) {
//       let factorial = 1;
//       for (let j = 1; j <= i; j++) {
//         factorial *= j;
//       }
//       console.log(i + "!=" + factorial);
//     }
//   }
  
//   let number = 4;
//   calculateFactorials(number);







//3





// function calculateSumOfFactorials(n) {
//     let sum = 0;
//     for (let i = 1; i <= n; i++) {
//       let factorial = 1;
//       for (let j = 1; j <= i; j++) {
//         factorial *= j;
//       }
//       sum += factorial;
//     }
//     return sum;
//   }
  
//   let number = 5;
//   console.log("1 to " + number + " is: " + calculateSumOfFactorials(number));








// 4




// function isLuckyNumber(num) {
//     let numString = num.toString();
//     for (let i = 0; i < numString.length; i++) {
//     if (numString[i] !== '4' && numString[i] !== '7') {
//     return "not lucky number";
//     }
//     }
//     return "lucky number";
//     }
    
//     let num = 47;
//     console.log(isLuckyNumber(num));







//5

// function countDigits(num) {
//     return num.toString().length;
// }

// let n = 1007;
// console.log(countDigits(n));







// 6.

// lolor(array, subtractNum, addNum) {
//     for (let i = 0; i < array.length; i++) {
//       if (array[i] === subtractNum) {
//         array.splice(i, 1);
//         break;
//       }
//     }
    
//     for (let i = 0; i < array.length; i++) {
//       if (addNum < array[i]) {
//         array.splice(i, 0, addNum);
//         break;
//       }
//     }
    
//     if (array[array.length - 1] < addNum) {
//       array.push(addNum);
//     }
    
//     return array;
//   }
  
//   console.log(lolor([10, 20, 30, 40, 50, 60, 70, 80, 90], 5, 7, 1000));






// 7.
// function zerleg(num) {
//     let numStr = num.toString();
//     let numArr = numStr.split("").sort((a, b) => b - a);
    
//     return parseInt(numArr.join(""));
//   }
  
//   console.log(zerleg(1928374));





// 8.


// function unemlehui(array1, array2) {
//     let honhor = [...array1, ...array2];
//     let shiliinArr = [...new Set(honhor)];
    
//     return shiliinArr;
//   }
  
//   console.log(unemlehui([3, 2, 30, 30, 1], []));








// 9.




// function unenguu(arr1, arr2) {
//     let even = arr1.filter(num => num % 2 !== 0);
//     let odd = arr2.filter(num => num % 2 === 0);
    
//     return [...even, ...odd];
//   }
  
//   console.log(unenguu([1, 3, 5, 7, 9], [2, 4, 6, 8, 10]));





// 10.

// function logo(first, length) {
//     var array = [];
//     var multiplier = 1;
    
//     while (array.length < length) {
//       array.push(first * multiplier);
//       multiplier++;
//     }
    
//     return array;
//   }
  
//   console.log(logo(7, 7));
