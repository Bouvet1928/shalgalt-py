let shalgah = document.getElementById('btn');

let pass1 = document.getElementById("password");
let pass2 = document.getElementById("password2");

shalgah.addEventListener('click', strong);
function strong(){
    if(pass1.value == pass2.value){
        alert('Amjilttai');
    }else{
        alert('passaa dahin shalgana uu!');
    }
}

function project() {
    var pass = document.getElementById("password");
    var upper = document.getElementById("upper");
    var lower = document.getElementById("lower");
    var special_char = document.getElementById("special_char");
    var num = document.getElementById("number");
    var length = document.getElementById("length");

    if (pass.value.match(/[0-9]/)) {
      num.style.color = "green";
    } else {
      num.style.color = "red";
    }

    if (pass.value.match(/[A-Z]/)) {
      upper.style.color = "green";
    } else {
      upper.style.color = "red";
    }

    if (pass.value.match(/[a-z]/)) {
      lower.style.color = "green";
    } else {
      lower.style.color = "red";
    }

    if (pass.value.match(/\W/)) {
      special_char.style.color = "green";
    } else {
      special_char.style.color = "red";
    }

}
